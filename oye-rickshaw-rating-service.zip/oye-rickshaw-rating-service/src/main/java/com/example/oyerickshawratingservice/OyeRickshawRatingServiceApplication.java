package com.example.oyerickshawratingservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OyeRickshawRatingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OyeRickshawRatingServiceApplication.class, args);
	}

}
