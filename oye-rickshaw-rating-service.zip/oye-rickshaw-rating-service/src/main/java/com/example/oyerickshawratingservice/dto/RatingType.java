package com.example.oyerickshawratingservice.dto;

public enum RatingType {
    RIDE, PASSENGER
}
